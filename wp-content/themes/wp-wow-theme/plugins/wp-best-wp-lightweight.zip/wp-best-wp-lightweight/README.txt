=== Plugin Name ===
Contributors: baonguyenyam
Tags: system, admin, configure, setup, lightweight
Requires at least: 4.7
Tested up to: 5.8
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Best WP Lightweight help you configure your websites without any coding knowledge required. Lightweight and using best practices for fastest load time.

== Description ==

Best WP Lightweight help you configure your websites without any coding knowledge required. Lightweight and using best practices for fastest load time.

== Installation ==

= From WordPress backend =

1. Navigate to Plugins -> Add new.
2. Click the button "Upload Plugin" next to "Add plugins" title.
3. Upload the downloaded zip file and activate it.

= Direct upload =

1. Upload the downloaded zip file into your `wp-content/plugins/` folder.
2. Unzip the uploaded zip file.
3. Navigate to Plugins menu on your WordPress admin area.
4. Activate this plugin.

== Screenshots ==

The screenshot is stored in the /assets directory.

== Changelog ==

= 1.0.0 =
* First version.
