<?php
$output .= '<article class="wow-vc-ctn'.$textAlign.$css_animation.'">';