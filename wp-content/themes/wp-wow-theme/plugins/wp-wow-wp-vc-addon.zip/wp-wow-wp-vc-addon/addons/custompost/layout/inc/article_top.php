<?php 
$output .= '<article class="wow-vc-ctn'.($add_box_button ? ' wow-vc-hold-click' : '').'">';
$output .= '<div class="wow-vc-box">';