<?php
include 'inc/article_top.php';
include 'inc/article_heading.php';
include 'inc/article_meta.php';
include 'inc/article_img.php';
include 'inc/article_content.php';
include 'inc/article_bottom.php';