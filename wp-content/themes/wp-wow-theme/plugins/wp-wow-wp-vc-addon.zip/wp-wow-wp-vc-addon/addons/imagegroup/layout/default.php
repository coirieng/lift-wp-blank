<?php 
include 'inc/img.php';
include 'inc/heading.php';
include 'inc/content.php';
