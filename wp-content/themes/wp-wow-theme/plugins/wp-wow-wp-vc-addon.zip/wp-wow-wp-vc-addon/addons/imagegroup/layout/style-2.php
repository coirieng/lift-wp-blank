<?php 
include 'inc/img.php';
$output .= '<div class="wow-vc-action">';
include 'inc/heading.php';
include 'inc/content.php';
$output .= '</div>';
