<?php
$output .= $content ? '<div class="wow-vc-content"><p>'. do_shortcode($content) .'</p></div>' : null;
