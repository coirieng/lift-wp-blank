<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="1" y="11" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="62" height="42"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="1" y1="17" x2="63" y2="17"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="1" y1="25" x2="63" y2="25"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="6" y1="47" x2="10" y2="47"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="12" y1="47" x2="41" y2="47"/>
</svg>
