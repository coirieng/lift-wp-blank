<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<ellipse fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="21" cy="53" rx="6" ry="4"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M25,56c0,0,2,1,2,4s-2,3-2,3"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="22,49 5,12 40,18 59,1 59,41 26,51 "/>
</svg>
