<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<g>
		<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,1c-0.672,0-1.339,0.021-2,0.063"/>
		<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4.0593,2.0296" d="M27.979,1.258
			C12.758,3.229,1,16.241,1,32c0,16.104,12.279,29.34,27.986,30.855"/>
		<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M30,62.937C30.661,62.979,31.328,63,32,63"/>
	</g>
</g>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,1c17.121,0,31,13.879,31,31
	c0,6.713-2.134,12.926-5.759,18l-5.62,5.621"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="51,45 51,56 
	62,56 "/>
</svg>
