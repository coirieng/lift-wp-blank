<?php
$output .= $icon ? $this->applyIcon($icon) : null;