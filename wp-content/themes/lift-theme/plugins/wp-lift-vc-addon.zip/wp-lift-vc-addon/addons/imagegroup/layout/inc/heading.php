<?php
$output .= $title ? $this->applyHeadingCustomPost($title,$tag,'#') : null;
