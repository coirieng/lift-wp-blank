<?php
$output .= $content ? '<div class="lift-content"><p>'. do_shortcode($content) .'</p></div>' : null;
