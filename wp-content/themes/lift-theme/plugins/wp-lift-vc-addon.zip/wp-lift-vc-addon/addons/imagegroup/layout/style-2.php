<?php 
include 'inc/img.php';
$output .= '<div class="lift-action">';
include 'inc/heading.php';
include 'inc/content.php';
$output .= '</div>';
