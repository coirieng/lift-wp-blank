<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?> 
<span class="wow-form-field-item wow-form-field-input">
    <input type="text" name="wow_default_form[<?php echo $fieldIndex; ?>]" <?php echo $fieldAttr; ?> >
</span>