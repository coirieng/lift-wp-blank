jQuery(document).ready(function ($) {
  "use strict";
  $('[id*="nectar-metabox-"] .buttonset').buttonset();
});
