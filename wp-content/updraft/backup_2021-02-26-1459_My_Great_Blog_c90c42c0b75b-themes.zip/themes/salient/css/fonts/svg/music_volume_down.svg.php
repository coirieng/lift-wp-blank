<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="8,32 8,20 20,20 38,2 38,32 38,62 20,44 
		8,44 	"/>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M46,42c5.522,0,10-4.478,10-10s-4.478-10-10-10"/>
</g>
</svg>
