<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="1,30 1,1 63,1 63,63 34,63 "/>
<g>
	<g>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="31,35 31,33 29,33 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="27" y1="33" x2="4" y2="33"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="3,33 1,33 1,35 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="1" y1="37" x2="1" y2="60"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="1,61 1,63 3,63 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="5" y1="63" x2="28" y2="63"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="29,63 31,63 31,61 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="31" y1="59" x2="31" y2="36"/>
	</g>
</g>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="41,12 41,23 
	52,23 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="41" y1="23" x2="57" y2="7"/>
</svg>
