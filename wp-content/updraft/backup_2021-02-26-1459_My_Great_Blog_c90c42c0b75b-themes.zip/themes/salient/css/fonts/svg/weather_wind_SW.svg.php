<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="31"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="4"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M23.515,23.515C18.828,28.201,15,48.999,15,48.999
	s20.799-3.827,25.485-8.514c4.687-4.688,4.686-12.285,0-16.971C35.8,18.828,28.201,18.827,23.515,23.515z"/>
</svg>
