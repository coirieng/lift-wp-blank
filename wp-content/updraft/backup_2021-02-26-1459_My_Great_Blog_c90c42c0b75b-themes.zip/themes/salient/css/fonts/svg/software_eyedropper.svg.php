<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M47,26l12-12l4-4c0-4.371-4.628-9-9-9
	c0,0-2.563,2.533-4,4L38,17"/>
<rect x="28.479" y="20.672" transform="matrix(-0.7071 -0.7071 0.7071 -0.7071 52.5208 68.7548)" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="24.042" height="5.657"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="34,22 4,54 4,56 1,59 5,63 8,60 10,60 
	42,30 "/>
</svg>
