<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="31"/>
	<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="8"/>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,48c-8.838,0-16-7.16-16-16"/>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32.002,48"/>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,16c8.838,0,16,7.162,16,16"/>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,9"/>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32.003,55C19.299,55,9,44.707,9,32"/>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32.003,55"/>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M55,32.002"/>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,9c12.704,0,23,10.295,23,23"/>
</g>
</svg>
