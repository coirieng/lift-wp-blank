<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="30,42 26,46 18,38 22,34 62,1 63,2 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="34" x2="30" y2="42"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M26,46c0,0-8,17-25,17c0,0,2.752-16.314,9-21
	c4-3,8-4,8-4"/>
</svg>
