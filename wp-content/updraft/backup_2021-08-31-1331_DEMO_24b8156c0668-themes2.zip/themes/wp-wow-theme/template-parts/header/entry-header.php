<?php
/**
 * Displays the post header
 *
 * @package WOW WordPress 
 * @subpackage Theme by Nguyen Pham
 * https://baonguyenyam.github.io
 * @since 2021
 */

the_title( '<h1 class="entry-title">', '</h1>' );
