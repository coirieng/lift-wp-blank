JS and SASS will be compile to /dist folder by `Sass/Less/Stylus/Pug/Jade/Typescript/Javascript Compile Hero Pro` plugins
