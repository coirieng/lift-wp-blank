<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,55h25v-4l-7-7V25c0-9.941-8.059-18-18-18
	s-18,8.059-18,18v19l-7,7v4H32z"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="14" y1="41" x2="50" y2="41"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="14" y1="35" x2="50" y2="35"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M39,55c0,4.418-3.582,8-8,8s-8-3.582-8-8"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="28,7 28,1 36,1 36,7 "/>
</svg>
