<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="23" y="57" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="18" height="6"/>
<rect x="19" y="47" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="26" height="10"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="41,47 41,43 48,30 32,1 16,30 23,43 23,47 
	"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="28.875" r="4"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="1" x2="32" y2="25"/>
</svg>
