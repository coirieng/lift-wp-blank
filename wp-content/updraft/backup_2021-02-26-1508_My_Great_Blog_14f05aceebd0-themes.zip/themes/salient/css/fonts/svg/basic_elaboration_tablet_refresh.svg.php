<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M24,30c0,4.418,3.582,9,8,9h4"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="33,43 36,39 
	33,35 "/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M42,30c0-4.418-3.582-9-8-9h-4"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="33,17 30,21 
	33,25 "/>
<g>
	<rect x="11" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="42" height="62"/>
</g>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="28" y1="5" x2="36" y2="5"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="11" y1="51" x2="53" y2="51"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="11" y1="9" x2="53" y2="9"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" cx="32" cy="57" r="2"/>
</svg>
