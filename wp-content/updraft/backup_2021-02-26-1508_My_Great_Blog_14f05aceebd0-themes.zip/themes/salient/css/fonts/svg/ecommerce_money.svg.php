<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="44" cy="38" r="19"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="44" cy="38" r="13"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="30,51 1,51 1,57 38,57 38,56 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="27,45 3,45 3,51 30,51 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="26,39 5,39 5,45 27,45 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="26,33 1,33 1,39 26,39 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="29,27 3,27 3,33 26,33 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="35,21 1,21 1,27 29,27 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="40,20 40,15 3,15 3,21 35,21 "/>
<rect x="1" y="9" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="37" height="6"/>
</svg>
