<?php
/**
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WOW WordPress 
 * @subpackage Theme by Nguyen Pham
 * https://baonguyenyam.github.io
 * @since 2021
 */

?>
				</div><!-- #wrapper -->
			</div><!-- #main -->
		</div><!-- #primary -->
</main><!-- #content -->

	<?php get_template_part( 'template-parts/footer/footer-widgets' ); ?>


</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
