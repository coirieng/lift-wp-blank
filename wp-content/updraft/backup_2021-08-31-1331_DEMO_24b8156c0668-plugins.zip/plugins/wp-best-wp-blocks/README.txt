=== Plugin Name ===
Contributors: baonguyenyam
Tags: block, builder. content, insert, admin
Requires at least: 4.7
Tested up to: 5.8
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Best WP Blocks help you create content blocks which can be used in posts, pages and widgets.

== Description ==

Best WP Blocks help you create content blocks which can be used in posts, pages and widgets.

== Installation ==

= From WordPress backend =

1. Navigate to Plugins -> Add new.
2. Click the button "Upload Plugin" next to "Add plugins" title.
3. Upload the downloaded zip file and activate it.

= Direct upload =

1. Upload the downloaded zip file into your `wp-content/plugins/` folder.
2. Unzip the uploaded zip file.
3. Navigate to Plugins menu on your WordPress admin area.
4. Activate this plugin.

== Screenshots ==

The screenshot is stored in the /assets directory.

== Changelog ==

= 1.0.0 =
* First version.
