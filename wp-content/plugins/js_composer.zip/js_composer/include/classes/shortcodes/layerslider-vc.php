<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_Layerslider_Vc extends WPBakeryShortCode {

}
